#!/bin/bash
set -e
cp /assets/docs/write_to_sd.bat /boot/docs/
cp /assets/docs/rtr.desktop /boot/docs/
cp /assets/docs/FieldManual.pdf /boot/
