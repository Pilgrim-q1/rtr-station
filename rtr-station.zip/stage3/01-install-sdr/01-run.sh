#!/bin/bash
set -e
pip3 install pyrtlsdr plotly
mkdir -p /opt/rtr
cp -r /assets/webui/* /opt/rtr/
cp /assets/services/rtr_web.service /etc/systemd/system/
cp /assets/services/rtr_logger.service /etc/systemd/system/
systemctl enable rtr_web
systemctl enable rtr_logger
