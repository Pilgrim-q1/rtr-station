# RTR Station OS Image

This project builds a custom Raspberry Pi OS image with:
- RTL-SDR support
- Live Spectrogram Viewer
- Web interface on port 5000
- LoRa/WiFi signal recognition
- Auto-start services for web & logging

## How to Use
1. Fork this repo
2. Enable GitHub Actions
3. Wait ~40 min
4. Download image from Releases
